import { expect, test } from '@playwright/test'

const authFile = 'playwright/.auth/user.json';
// Add this line here to completely reset the state for this file:
test.use({ storageState: authFile });


test.describe.serial('Shopping Cart Session Tests', () => {
test('Session store test', async ({ page }) => {

    await page.goto('https://rahulshettyacademy.com/client/#/auth/login');
    await page.getByRole('textbox', { name: 'Email' }).fill("mak_powerful@yahoo.co.in");
    await page.getByPlaceholder('enter your passsword').fill("Arthas1@3");
    await page.getByRole('button', { name: 'Login' }).click();

    // Wait for the route to change to confirm the login transaction succeeded
    await page.waitForURL(/#\/dashboard/);
    await page.getByRole('button', { name: 'Add To Cart' }).first().click();
    // Save the cached storage state cleanly out to our designated JSON path
    await page.context().storageState({ path: authFile });

});


test('Opening stored session', async ({ page }) => {

    await page.goto('https://rahulshettyacademy.com/client/#/dashboard/cart');
    const items = page.locator("//li[contains(@class,'items')]");
    await expect(items).toHaveCount(1);
    console.log(await items);
    page.pause();
});

});