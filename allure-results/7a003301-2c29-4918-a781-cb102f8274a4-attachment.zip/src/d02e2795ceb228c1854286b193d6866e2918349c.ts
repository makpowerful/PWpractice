import { expect, test } from '@playwright/test';

const authFile = 'playwright/.auth/user.json';
test.use({ storageState: authFile });

test.describe.serial('Shopping Cart Session Tests', () => {
    
    test('Session store test', async ({ page }) => {
        await page.goto('https://rahulshettyacademy.com/client/#/auth/login');
        
        // 🔑 CHANGED: Using exact element IDs instead of getByRole
        await page.locator('#userEmail').fill("mak_powerful@yahoo.co.in");
        await page.locator('#userPassword').fill("Arthas1@3");
        
        await page.getByRole('button', { name: 'Login' }).click();

        await page.waitForURL(/.*dashboard/);
        await page.context().storageState({ path: authFile });
    });

    test('Opening stored session', async ({ page }) => {
        await page.goto('https://rahulshettyacademy.com/client/#/dashboard/cart');
        
        const items = page.locator("//li[contains(@class,'items')]");
        await expect(items).toHaveCount(1);
        console.log(await items.allTextContents());
        await page.pause();
    });
});
